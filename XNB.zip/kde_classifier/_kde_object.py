class KDE():
    def __init__(self, feature:str, target:str, x_points:list, y_points:list) -> None:
        self.feature = feature
        self.target = target
        self.x_points = x_points
        self.y_points = y_points