from kde_classifier.stratified_naive_bayes import Stratified_NB
from sklearn.metrics import accuracy_score
import pandas as pd
import numpy as np

from sklearn.naive_bayes import GaussianNB
import sklearn.model_selection as model_selection
from sklearn.metrics import accuracy_score

import time
import os 

offset_print = 80
class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    RED = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

#os.system('clear')
print('INICIO EJECUCION')
dataset_name = ""

inicio_total = time.time()

def iris_dataset() -> tuple[pd.DataFrame, pd.Series]:
    inicio = time.time()
    global dataset_name
    dataset_name = "data/iris.csv"
    df = pd.read_csv(dataset_name, sep=',')
    X, y = df.iloc[:, 0:-1], df.iloc[:,-1]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return  X, y

def Leukemia_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 7129 #Examples: 72 #Classes: 2
    inicio = time.time()
    global dataset_name
    dataset_name = "data/LEUKEMIA.csv"
    df = pd.read_csv(dataset_name, sep=',')
    X, y = df.iloc[:, 0:-1], df.iloc[:,-1]
    return  X, y

def Dry_Beans_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 16 #Examples: 13611 #Classes: 7
    """ 
        Accuracy SNB  Accuracy NB  Accuracy FSNB       #VAR
    0      0.895007     0.748899       0.748899  13.714286
    1      0.902278     0.773696       0.773696  13.714286
    2      0.896400     0.767083       0.767083  13.285714
    3      0.887583     0.762675       0.762675  13.714286
    4      0.902278     0.745775       0.745775  13.714286
    5      0.903747     0.766348       0.766348  13.714286
    6      0.897134     0.781778       0.781778  13.714286
    7      0.891991     0.756796       0.756796  13.714286
    8      0.903747     0.777370       0.777370  13.714286
    9      0.894195     0.753123       0.753123  13.714286

    ---------------------

    SBN: 0.8974360758749343 #VAR: 13.671428571428569
    NB: 0.7633542322793231 #VAR: 16
    FSNB: 0.7633542322793231 #VAR: 16
    #Class Distribution: {'BARBUNYA': 0.09714285714285714, 'BOMBAY': 0.038285714285714284, 'CALI': 0.11975510204081632, 'DERMASON': 0.26048979591836735, 'HOROZ': 0.1417142857142857, 'SEKER': 0.1489795918367347, 'SIRA': 0.19363265306122449}
    TOTAL TIME: 212.163 sec.
    
    """

    inicio = time.time()
    global dataset_name
    dataset_name = "data/Dry_Bean_Dataset.csv"
    df = pd.read_csv(dataset_name, sep=';')
    X, y = df.iloc[:, 0:-1], df.iloc[:,-1]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return  X, y

def Leukemia_GSE28497_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 22282 #Examples: 281 #Classes: 7 
    '''
        Accuracy SNB  Accuracy NB  Accuracy FSNB       #VAR
    0      0.842105     0.771930       0.789474  23.571429
    1      0.857143     0.821429       0.857143  26.857143
    2      0.821429     0.785714       0.875000  24.857143
    3      0.839286     0.821429       0.821429  25.000000
    4      0.857143     0.875000       0.910714  24.000000

    SBN: 0.843421052631579 #VAR: 24.857142857142858
    NB: 0.8151002506265664 #VAR: 22283
    FSNB: 0.850751879699248 #VAR: 73
    #Class Distribution: {'B-CELL_ALL': 0.26666666666666666, 'B-CELL_ALL_ETV6-RUNX1': 0.18666666666666668, 'B-CELL_ALL_HYPERDIP': 0.18222222222222223, 'B-CELL_ALL_HYPO': 0.06222222222222222, 'B-CELL_ALL_MLL': 0.06222222222222222, 'B-CELL_ALL_T-ALL': 0.16444444444444445, 'B-CELL_ALL_TCF3-PBX1': 0.07555555555555556}
    TOTAL TIME: 1077.304 sec.
    '''
    inicio = time.time()
    global dataset_name
    dataset_name = "data/Leukemia_GSE28497.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y


def Breast_GSE45827_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 54674 #Examples: 151 #Classes: 6
    inicio = time.time()
    global dataset_name
    dataset_name = "data/Breast_GSE45827.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def Breast_GSE42568_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 54674 #Examples: 116 #Classes: 2
    inicio = time.time()
    global dataset_name
    dataset_name = "data/Breast_GSE42568.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def Breast_GSE10797_dataset() -> tuple[pd.DataFrame, pd.Series]:
    
    inicio = time.time()
    global dataset_name
    dataset_name = "data/Breast_GSE10797.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def Breast_GSE26304_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 33636 #Examples: 115 #Classes: 4
    inicio = time.time()
    global dataset_name
    dataset_name = "data/Breast_GSE26304.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def Breast_GSE7904_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 54674 #Examples: 45 #Classes: 3
    """         
    Accuracy SNB  Accuracy NB  Accuracy FSNB      #VAR
    0      0.888889     0.888889       0.888889  2.666667
    1      1.000000     1.000000       1.000000  2.666667
    2      1.000000     0.888889       1.000000  2.000000
    3      1.000000     0.888889       1.000000  2.666667
    4      1.000000     0.888889       1.000000  2.666667

    SBN: 0.9777777777777779 #VAR: 2.533333333333333
    NB: 0.9111111111111111 #VAR: 54674
    FSNB: 0.9777777777777779 #VAR: 4
    #Class Distribution: {'normal_breast': 0.1388888888888889, 'tumoral_basal': 0.3888888888888889, 'tumoral_non_BLC': 0.4722222222222222}
    TOTAL TIME: 913.314 sec. 
    """
    inicio = time.time()
    global dataset_name
    dataset_name = "data/Breast_GSE7904.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def Bladder_GSE31189_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 54674 #Examples: 85 #Classes: 2 
    inicio = time.time()
    global dataset_name
    dataset_name = "data/Bladder_GSE31189.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def Brain_GSE50161_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 54674 #Examples: 130 #Classes: 5 
    '''
        Accuracy SNB  Accuracy NB  Accuracy FSNB  #VAR
    0      0.923077     0.923077       0.923077  14.6
    1      0.923077     0.923077       0.923077  14.2
    2      0.846154     0.846154       0.769231  14.4
    3      1.000000     1.000000       1.000000  16.4
    4      0.846154     0.846154       0.846154  15.6
    5      1.000000     1.000000       1.000000  15.6
    6      0.923077     1.000000       1.000000  16.2
    7      0.846154     0.846154       0.846154  14.4
    8      1.000000     0.846154       1.000000  15.8
    9      0.923077     0.923077       0.923077  14.4

    ---------------------

    SBN: 0.9230769230769231 #VAR: 15.16
    NB: 0.9153846153846155 #VAR: 54675
    FSNB: 0.9230769230769231 #VAR: 35
    #Class Distribution: {'ependymoma': 0.358974358974359, 'glioblastoma': 0.2564102564102564, 'medulloblastoma': 0.17094017094017094, 'normal': 0.10256410256410256, 'pilocytic_astrocytoma': 0.1111111111111111}
    TOTAL TIME: 3368.311 sec.
    '''
    inicio = time.time()
    global dataset_name
    dataset_name = "data/Brain_GSE50161.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def Colorectal_GSE77953_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 22282 #Examples: 55 #Classes: 4
    inicio = time.time()
    global dataset_name
    dataset_name = "data/Colorectal_GSE77953.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def Colorectal_GSE21510_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 54674 #Examples: 147 #Classes: 3
    inicio = time.time()
    global dataset_name
    dataset_name = "data/Colorectal_GSE21510.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def Ovary_GSE6008_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 22282 #Examples: 98 #Classes: 4
    inicio = time.time()
    global dataset_name
    dataset_name = "data/Ovary_GSE6008.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def HMF_PCAWG_onlynumeric_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 232 #Examples: 6756 #Classes: 35 
    '''
        Accuracy SNB  Accuracy NB  Accuracy FSNB        #VAR
    0      0.724852     0.140533       0.153846  103.057143
    1      0.710059     0.170118       0.201183  104.028571
    2      0.730769     0.143491       0.161243  105.085714
    3      0.744083     0.136095       0.174556  105.285714
    4      0.690828     0.147929       0.150888  105.542857
    5      0.659763     0.140533       0.167160  103.657143
    6      0.688889     0.134815       0.139259  105.914286
    7      0.677037     0.136296       0.160000  103.571429
    8      0.685926     0.122963       0.179259  103.714286
    9      0.693333     0.140741       0.160000  103.142857
    ---------------------
    SBN: 0.7005540214770984 #VAR: 104.3
    NB: 0.14135130396668857 #VAR: 232
    FSNB: 0.16473942581634887 #VAR: 207
    #Class Distribution: {'Biliary': 0.016938003617826016, 'Breast': 0.14750863344844597, 'CNS_Glioma': 0.019404703173820096, 'CNS_Medullo': 0.020555829633284, 'CNS_PiloAstro': 0.008551225127446143, 'Cervix': 0.008715671764512416, 'Colorectal': 0.1050814010853478, 'Gastroesophageal': 0.04851175793455024, 'HeadAndNeck_Other': 0.013484624239434303, 'HeadAndNeck_SalivaryGland': 0.0050978457490544315, 'Kidney_Chromophobe': 0.006413418845584608, 'Kidney_ClearCell': 0.035191580332182205, 'Kidney_Papillary': 0.004768952474921888, 'Liver': 0.05032067094227923, 'Lung_NonSmallCell': 0.08699227100805788, 'Lung_SmallCell': 0.007893438579181056, 'Lymphoid': 0.03223154086498931, 'Mesothelium': 0.006084525571452064, 'Myeloid': 0.00493339911198816, 'NET_Gastrointestinal': 0.007893438579181056, 'NET_Lung': 0.0037822726525242557, 'NET_Pancreas': 0.017595790166091103, 'Ovarian': 0.04209833908896563, 'Pancreas': 0.051307350764676865, 'Prostate': 0.08288110508140109, 'Sarcoma_GIST': 0.010031244861042591, 'Sarcoma_Leiomyo': 0.009537904949843776, 'Sarcoma_Lipo': 0.006084525571452064, 'Sarcoma_Osteo': 0.00657786548265088, 'Sarcoma_Other': 0.019404703173820096, 'Skin_Carcinoma': 0.003617826015457984, 'Skin_Melanoma': 0.06002302252918928, 'Thyroid': 0.00986679822397632, 'Urothelial': 0.02960039467192896, 'Uterus': 0.011017924683440223}
    TOTAL TIME: 2627.469 sec. 
    '''

    inicio = time.time()
    global dataset_name
    dataset_name = "data/HMF_PCAWG.cuplr_features.V1.233features.csv"
    df = pd.read_csv(dataset_name, sep=',')
    X, y = df.iloc[:, 0:-1], df.iloc[:,-1]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def HMF_PCAWG_new_onlynumeric_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 232 #Examples: 6756 #Classes: 35
    '''
       Accuracy SNB  Accuracy NB  Accuracy FSNB        #VAR
    0      0.730769     0.158284       0.178254  101.885714
    1      0.709104     0.137676       0.162102  104.828571
    2      0.669874     0.148779       0.159882  105.000000
    3      0.701702     0.139156       0.162102  104.085714
    4      0.720207     0.134715       0.172465  101.857143
    ---------------------
    SBN: 0.706331492341855 #VAR: 103.53142857142856
    NB: 0.14372194166933108 #VAR: 232
    FSNB: 0.16696102821053002 #VAR: 205
    TOTAL TIME: 2948.918 sec.
    '''
    inicio = time.time()
    global dataset_name
    dataset_name = "data/233_features.csv"
    df = pd.read_csv(dataset_name, sep=',')
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def HMF_PCAWG_new_allnumeric_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 3331 #Examples: 6756 #Classes: 35
    '''
       Accuracy SNB  Accuracy NB  Accuracy FSNB        #VAR
    0      0.683432     0.144231       0.150888  105.857143
    1      0.692080     0.116950       0.132494  109.200000
    2      0.649889     0.133235       0.150259  109.628571
    3      0.666913     0.134715       0.144338  109.371429
    4      0.692820     0.124352       0.145078  104.685714
    ---------------------
    SBN: 0.6770268790595615 #VAR: 107.74857142857142
    NB: 0.13069663497124637 #VAR: 3331
    FSNB: 0.14461126756862108 #VAR: 282
    TOTAL TIME: 6671.516 sec.
    '''
    inicio = time.time()
    global dataset_name
    dataset_name = "data/3332_features.csv"
    df = pd.read_csv(dataset_name, sep=',')
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def HMF_PCAWG_all_dataset() -> tuple[pd.DataFrame, pd.Series]:
    inicio = time.time()
    df = pd.read_csv("data/HMF_PCAWG.cuplr_features.V3.463features.csv", sep=',')
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def HMF_PCAWG_new_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 511 #Examples: 6756 #Classes: 35 
    inicio = time.time()
    global dataset_name
    dataset_name = "data/HMF_PCAWG.cuplr_features.V1.511features.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def SDSC_complete_genes_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 63639 #Examples: 9080 #Classes: 51
    inicio = time.time()
    global dataset_name
    dataset_name = "data/SDSC_complete_genes.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def Lung_GSE7670_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 22283 #Examples: 51 #Classes: 2 
    inicio = time.time()
    global dataset_name
    dataset_name = "data/Lung_GSE7670.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def Throat_GSE59102_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 32703 #Examples: 42 #Classes: 2
    inicio = time.time()
    global dataset_name
    dataset_name = "data/Throat_GSE59102.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def Renal_GSE53757_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 54675 #Examples: 143 #Classes: 2
    inicio = time.time()
    global dataset_name
    dataset_name = "data/Renal_GSE53757.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def Pancreatic_GSE16515_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 54675 #Examples: 51 #Classes: 2 
    inicio = time.time()
    global dataset_name
    dataset_name = "data/Pancreatic_GSE16515.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y


def Prostate_GSE11682_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 33467 #Examples: 31 #Classes: 2
    inicio = time.time()
    global dataset_name
    dataset_name = "data/Prostate_GSE11682.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def Prostate_GSE46602_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 54675 #Examples: 49 #Classes: 2 
    inicio = time.time()
    global dataset_name
    dataset_name = "data/Prostate_GSE46602.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def Brain_GSE15824_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 54675 #Examples: 37 #Classes: 4 
    inicio = time.time()
    global dataset_name
    dataset_name = "data/Brain_GSE15824.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def Bladder_GSE40355_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 29044 #Examples: 24 #Classes: 3  --- No funciona, demasiados splits (10) para tan pocos ejemplos (24)
    inicio = time.time()
    global dataset_name
    dataset_name = "data/Bladder_GSE40355.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def Leukemia_GSE71449_dataset() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 52200 #Examples: 45 #Classes: 4 --- No funciona, hay clases con solo 1 ejemplo
    inicio = time.time()
    global dataset_name
    dataset_name = "data/Leukemia_GSE71449.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 1:], df.iloc[:,0]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def musk_v2() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 54674 #Examples: 151 #Classes: 6
    inicio = time.time()
    global dataset_name
    dataset_name = "/Users/aguilar/Documents/DATOS/DATASETS/UCI/DEF/numeric/musk_v2.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 0:-1], df.iloc[:,-1]
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def movement_libras() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 54674 #Examples: 151 #Classes: 6
    inicio = time.time()
    global dataset_name
    dataset_name = "/Users/aguilar/Documents/DATOS/DATASETS/UCI/DEF/numeric/movement_libras.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 0:-1], df.iloc[:,-1]
    y = y.astype(str)
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y

def sonar() -> tuple[pd.DataFrame, pd.Series]:
    #Variables: 54674 #Examples: 151 #Classes: 6
    inicio = time.time()
    global dataset_name
    dataset_name = "/Users/aguilar/Documents/DATOS/DATASETS/UCI/DEF/numeric/sonar.csv"
    df = pd.read_csv(dataset_name, sep=',')
    df = df.drop('samples', errors='ignore',axis=1)
    X, y = df.iloc[:, 0:-1], df.iloc[:,-1]
    y = y.astype(str)
    fin = time.time()
    print(f'T. LOAD FILE: {fin-inicio:.3f} sec.'.rjust(offset_print))
    return X, y


''' 1. Read the dataset. '''

#X, y = musk_v2()
#X, y = movement_libras()
X, y = sonar()
#X, y = iris_dataset() 
#X, y = Dry_Beans_dataset()
#X, y = HMF_PCAWG_onlynumeric_dataset()
#X, y = Leukemia_GSE28497_dataset()
#X, y = Breast_GSE45827_dataset()
#X, y = Breast_GSE7904_dataset()
#X, y = Brain_GSE50161_dataset()
#X, y = Breast_GSE26304_dataset()
#X, y = Leukemia_dataset()
#X, y = Ovary_GSE6008_dataset()
#X, y = Colorectal_GSE77953_dataset()
#X, y = Colorectal_GSE21510_dataset()
#X, y = Bladder_GSE31189_dataset()
#X, y = Leukemia_GSE28497_dataset()
#X, y = Breast_GSE42568_dataset()
#X, y = Breast_GSE10797_dataset()
#X, y = Lung_GSE7670_dataset()
#X, y = HMF_PCAWG_new_dataset()
#X, y = HMF_PCAWG_new_allnumeric_dataset()
#X, y = Throat_GSE59102_dataset()
#X, y = Renal_GSE53757_dataset()
#X, y = Pancreatic_GSE16515_dataset()
#X, y = Prostate_GSE11682_dataset()
#X, y = Prostate_GSE46602_dataset()
#X, y = Brain_GSE15824_dataset()
#X, y = Bladder_GSE40355_dataset()
#X, y = Leukemia_GSE71449_dataset()
#X, y = SDSC_complete_genes_dataset()


print(f"{bcolors.OKBLUE}---------------------------------------------{bcolors.ENDC}")
print(f'{bcolors.OKBLUE}#Variables: {len(X.columns)} #Examples: {len(X)} #Classes: {len(y.unique())} {bcolors.ENDC}'.rjust(offset_print))
print(f"{bcolors.OKBLUE}---------------------------------------------{bcolors.ENDC}")

def generate_table_feature_class(feature_selection:dict) -> pd.DataFrame:
    values = list(feature_selection.values())
    variables = list(set([var for x in values for var in x]))
    # We create a dataframe with 1 row per variable
    df = pd.DataFrame({'variables': variables})
    # We create a column for each class
    for c in feature_selection:
        df[str(c)] = [1 if x in feature_selection[c] else 0 for x in variables]
    # We set as index of the DF the variable column
    df = df.set_index('variables')
    # We create an auxiliary column with the total number of times that each variable appears
    df['total'] = df.sum(axis=1)
    # We order the DF on the basis of this auxiliary column
    return df.sort_values(by='total', ascending=False).copy()



skf = model_selection.StratifiedKFold(n_splits = 10, shuffle = True, random_state = 0)

accuracy_list = {'snb':[], 'fsnb':[], 'nb':[], 'snb_new':[]}
n_features_selected = []
iteration = 0
table_feature_class = []

for train_index, test_index in skf.split(X, y):

    print(f'{bcolors.OKGREEN}FOLD: {iteration+1}{bcolors.ENDC}'.rjust(0))

    X_train, X_test = X.iloc[train_index], X.iloc[test_index]
    y_train, y_test = y.iloc[train_index], y.iloc[test_index]

    # X_train, X_test = X, X
    # y_train, y_test = y, y

    # STRATIFIED NB
    inicio = time.time()
    snb = Stratified_NB()
    snb.fit(X_train, y_train)
    snb.feature_selection_dict = dict(sorted(snb.feature_selection_dict.items()))
    feature_selection = snb.feature_selection_dict

    variable_count = [len(feature_selection[i]) for i in feature_selection]
    n_features_selected.append(sum(variable_count)/len(variable_count))

    #y_pred = snb.predict(X_test)
    #r3 = accuracy_score(y_test, y_pred)
    #accuracy_list['snb'].append(r3)

    y_pred_new = snb.predict_new(X_test)
    r3_new = accuracy_score(y_test, y_pred_new)
    accuracy_list['snb_new'].append(r3_new)

    fin = time.time()
    print(f'SNB: {fin-inicio:.3f} sec.'.rjust(offset_print))

    # ORIGINAL NB
    inicio = time.time()
    nb = GaussianNB()
    nb.fit(X_train,y_train)
    y_pred = nb.predict(X_test)
    r1 = accuracy_score(y_test, y_pred)
    accuracy_list['nb'].append(r1)
    fin = time.time()
    print(f'NB: {fin-inicio:.3f} sec.'.rjust(offset_print))

    # FEATURE SELECTION NB
    inicio = time.time()
    new_cols = list({x for v in feature_selection.values() for x in v})
    nb = GaussianNB()
    nb.fit(X_train[new_cols],y_train)
    y_pred = nb.predict(X_test[new_cols])
    r2 = accuracy_score(y_test, y_pred)
    accuracy_list['fsnb'].append(r2)
    fin = time.time()
    print(f'FSNB: {fin-inicio:.3f} sec.'.rjust(offset_print))

    iteration = iteration + 1

    table_features = generate_table_feature_class(feature_selection)
    print(table_features)
    print("# Uniq. Var:  " + str(len(set(table_features.index))))

    print(f"{bcolors.OKBLUE}\n---------------------------------------------\n{bcolors.ENDC}")
    print(f'{bcolors.OKBLUE}NB: {r1:.3f} #Var = {len(X_train.columns):.1f}{bcolors.ENDC}'.rjust(offset_print))
    print(f'{bcolors.OKBLUE}FS+NB: {r2:.3f} #Var = {len(new_cols):.1f}{bcolors.ENDC}'.rjust(offset_print))
    #print(f'{bcolors.OKBLUE}SNB: {r3:.3f} #Var = {sum(variable_count)/len(variable_count):.1f} Vars = {variable_count}{bcolors.ENDC}'.rjust(offset_print))
    print(f'{bcolors.OKBLUE}XNB: {r3_new:.3f} #Var = {sum(variable_count)/len(variable_count):.1f} Vars = {variable_count}{bcolors.ENDC}'.rjust(offset_print))
    print(f"{bcolors.OKBLUE}\n---------------------------------------------\n{bcolors.ENDC}")
    #print(feature_selection)


    # Nuevo código para generar una matriz binaria. En filas, los genes. En columnas, las clases. Una posición (gen, clase) tendrá un 1 si para esa clase está el gen en su lista; y un 0 en caso contrario.
    # Se generarán tantas tablas como iteraciones existan en la validación cruzada, incluyendo cada una en la variable table_feature_class.
    # feature_matrix = generate_table_feature_class(feature_selection)
    # table_feature_class.append(feature_matrix)
    

#results = pd.DataFrame({'Accuracy SNB':accuracy_list['snb'], 'Accuracy SNB NEW':accuracy_list['snb_new'], 'Accuracy NB':accuracy_list['nb'], 'Accuracy FSNB':accuracy_list['fsnb'], '#VAR':n_features_selected})
results = pd.DataFrame({'Accuracy XNB':accuracy_list['snb_new'], 'Accuracy NB':accuracy_list['nb'], 'Accuracy FS+NB':accuracy_list['fsnb'], '#VAR':n_features_selected})

snb_mean = results['Accuracy XNB'].mean()
nb_mean = results['Accuracy NB'].mean()
fsnb_mean = results['Accuracy FS+NB'].mean()
n_features_mean = results['#VAR'].mean()

print("\n---------------------\n")
print("Dataset: " + dataset_name + "\n")
print(f"{bcolors.OKBLUE}---------------------------------------------{bcolors.ENDC}")
print(f'{bcolors.OKBLUE}#Variables: {len(X.columns)} #Examples: {len(X)} #Classes: {len(y.unique())} {bcolors.ENDC}'.rjust(offset_print))
print(f"{bcolors.OKBLUE}---------------------------------------------{bcolors.ENDC}")
print(results)
print("\n---------------------\n")

print("XNB: "+str(snb_mean)+" #VAR: "+str(n_features_mean))
print("NB: "+str(nb_mean)+" #VAR: "+str(len(X.columns)))
print("FS+NB: "+str(fsnb_mean)+" #VAR: "+str(len(new_cols)))

#print(f'{bcolors.OKBLUE}#Class Distribution: {dict(sorted(snb._class_representation.items()))}{bcolors.ENDC}'.rjust(offset_print))



fin_total = time.time()
print(f'{bcolors.RED}TOTAL TIME: {fin_total-inicio_total:.3f} sec.{bcolors.ENDC}'.rjust(offset_print))


""" X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=0)

''' 2. By calling the fit() function, we prepare the class to be able to make the prediction later. '''
snb = Stratified_NB()
snb.fit(X_train, y_train)

''' 3. When the fit() function finishes, we can now access the feture selection it has calculated. '''
feature_selection = snb.feature_selection_dict

''' 4. We predict the values of "y_test" thanks to the calculated dictionary. '''
y_pred = snb.predict(X_test)

# Output
print(feature_selection)
print(accuracy_score(y_test, y_pred)) """

